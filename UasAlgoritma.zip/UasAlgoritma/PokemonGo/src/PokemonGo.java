    import java.util.ArrayList;

    public class PokemonGo {
    import javax.xml.crypto.dsig.spec.XSLTTransformParameterSpec;
    import java.util.ArrayList;

        public class ArrayListModel {
            public static class Mobil {
                private String bug;
                private String dark;
                private String dragon;
                private String electric;



                public PokemonGo(){
                }

                public PokemonGo (String bug,String dark,String dragon,String electric){
                    this.bug = bug;
                    this.dark = dark;
                    this.dragon = dragon;
                    this.electric = electric
                }
                public String getBug() {
                    return this.bug;
                }
                public void setBug(String bug) {
                    this.bug = bug;
                }
                public String getDark() {
                    return this.dark;
                }
                public void setDark(String JumlahCC) {
                    this.dark = dark;
                }
                public String getDragon() {
                    return this.dragon;
                }
                public void setDragon(String dragon) {
                    this.dragon = dragon;
                }
                public int getElectric() {return  this.electric}
                public void setElectric(String electric) {
                    this.electric = electric;
                }
            }

            public static void main(String[] args) {
                ArrayList<PokemonGo> Pokemon = new ArrayList<>();
                PokemonGo pokemon = new pokemon();
                pokemon.setbug;
                pokemon.setdark;
                pokemon.setdragon;
                pokemon.setelectric;
                pokemon.add(pokemon);

            }
        }

    }
}
